# Nmbrs Accounting QA Automation Test

The goal of this test is to create a basic setup for an end-to-end tests solution using C#, Playwright and Reqnroll.

## What content you will find?

* **nmbrsaccounting_testsuite**: the folder containing the solution with the (empty) tests project you'll work on (`NmbrsAccounting.Tests.sln`)
* **nmbrsaccounting_webapp**: the folder containing the .NET solution of the web application to create tests for (`NmbrsAccounting.WebApp.sln`)

## What you're expected to do:

1. Run and analyze the suggestions in the web app
2. Open up the tests solution and setup the basic code to:
   * Configure Playwright and install the dependencies required for it to work
   * Setup the basic design for a reusable tests solution in C#
   * Implement (at least) the cases described in the webapp page, taking into account the following aspects:

* General coding best practices/patterns
* Automation testing best practices/patterns
* Performance (eg. execution in a pipeline, network latency, website response time delays, etc)
* Writing the code in a way it will keep working performantly in unattended contexts (eg. a CI/CD pipeline)

## Running the web application

```
cd nmbrsaccounting_webapp/NmbrsAccounting.WebApp
dotnet run
```

Then browse to `https://localhost:5001` (or `http://localhost:5000`).
